// Get mouse location:
var mouseX;
var mouseY;
$(document).mousemove(function(e) {
   mouseX = e.pageX; 
   mouseY = e.pageY;
});

//// Get selected text:
function getSelectedText() {
  var text = "";
  if (typeof window.getSelection != "undefined") {
      text = window.getSelection().toString();
  } else if (typeof document.selection != "undefined" && document.selection.type == "Text") {
      text = document.selection.createRange().text;
  }
  return text;
}

function doSomethingWithSelectedText() {
  var selectedText = getSelectedText();
  if (selectedText) {
    console.log(selectedText);
    $.get('http://rich-page.appspot.com/Snippet.jsp?q='+selectedText+'&m=w', function(data) {
      

      if(!data.error) {
        jQuery(document).ready(function($) {
          $('#myModal').remove();
          var text = data.data[0].revisions[0]['*'];
          debugger;
          $("body").append('<div id="myModal" class="modal hide fade">' + text + '</div>');

          // $('body').append('<div id="myModal">Hi</div>');

          $('#myModal').css({'top':mouseY, 'left':mouseX, position:'absolute'}).hide().fadeIn('slow');

          $('#myModal').modal({show:true, backdrop: false});

          $('body').click(function() {
            $('#myModal').fadeOut('slow');
            $('#myModal').remove();
          })

          // $("#myModal").mouseout(function(){
          //   $('#myModal').fadeOut('slow');
          //   $('#myModal').remove();
          // });

          // $(".classForHoverEffect").mouseover(function(){
          //   $('#myModal').css({'top':mouseY, 'left':mouseX, position:'absolute'}).fadeIn('slow');
          // });

          // $('.classForHoverEffect').hover(function(){
          //   $('#myModal').css({'top':mouseY, 'left':mouseX, position:'absolute'}).fadeIn('slow');
          // });

          
        });
        

//         $("body").append(

//           <div id="myModal" class="modal hide fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
//   <div class="modal-header">
//     <button type="button" class="close" data-dismiss="modal" aria-hidden="true">×</button>
//     <h3 id="myModalLabel">Modal header</h3>
//   </div>
//   <div class="modal-body">
//     <p>One fine body…</p>
//   </div>
//   <div class="modal-footer">
//     <button class="btn" data-dismiss="modal" aria-hidden="true">Close</button>
//     <button class="btn btn-primary">Save changes</button>
//   </div>
// </div>
// );


        


        console.log(data.data[0].revisions[0]['*']);


      } else {
        console.log(data.error);
      }
    });

    // $("body").append("<div id='popup' style='display:none;'>hello world</div>");
    // var popup = $('#popup');
    // $('#popup').css({'top':mouseY,'left':mouseX}).fadeIn('slow');    

  }
}

document.onmouseup = doSomethingWithSelectedText;
document.onkeyup = doSomethingWithSelectedText;

